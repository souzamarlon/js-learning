import { Router } from 'express';

const routes = new Router();

export default routes;
