export default {
  secret: 'f29618255c309de4469993cce24286ea',
  expiresIn: '7d',
};
